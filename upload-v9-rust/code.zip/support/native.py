"""Call the packaged Rust abi3 Python extension directly in this process."""
import threading

_SOLVER = None
_FAILED = False
_LOCK = threading.Lock()
LAST_ERROR = None
LAST_STATS = {}
BACKEND = "rust-pyo3-abi3"

try:
    from support import _c4solver
except ImportError as exc:
    _c4solver = None
    LAST_ERROR = repr(exc)


def available():
    return _c4solver is not None and not _FAILED


def warmup():
    global _SOLVER, _FAILED, LAST_ERROR
    if not available():
        return False
    with _LOCK:
        try:
            if _SOLVER is None:
                _SOLVER = _c4solver.Solver()
            result = _SOLVER.analyze(0, 0, 1)
            return len(result) == 6 and len(result[5]) == 7
        except Exception as exc:
            LAST_ERROR = repr(exc)
            _FAILED = True
            return False


def analyze(own, mask, budget_ms):
    global _SOLVER, LAST_STATS
    if not available():
        raise RuntimeError("Rust Python extension unavailable: " + str(LAST_ERROR))
    with _LOCK:
        if _SOLVER is None:
            _SOLVER = _c4solver.Solver()
        col, score, nodes, elapsed_ms, solved, wdl = _SOLVER.analyze(
            own, mask, max(1, min(int(budget_ms), 5000)))
        if not (0 <= col < 7 and score in (-127, -1, 0, 1) and len(wdl) == 7
                and all(v in (-1, 0, 1, 9) for v in wdl)):
            raise RuntimeError("Invalid Rust result")
        LAST_STATS = {"nodes": nodes, "elapsed_ms": elapsed_ms, "solved": solved,
                      "backend": BACKEND}
        return col, score, solved, wdl


def close():
    global _SOLVER
    with _LOCK:
        _SOLVER = None
